import json
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('TkAgg')  # 设置后端为 TkAgg（推荐）
from scipy.integrate import simps
from sklearn.linear_model import LinearRegression
from scipy.signal import find_peaks
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
# 假设你有一个名为data.json的文件
filename = r'F:/HuNan/JSON/Sec/Final.json'

# 打开文件并读取数据
with open(filename, 'r', encoding='utf-8') as file:
    data = json.load(file)

# 提取特征
num_features = 18  # 根据实际特征数量
feature_maxt = np.zeros((len(data), num_features))

for i in range(len(data)):
    try:
        data_sin = data[i]
        data_sig = data_sin["signal_Normalized"]
        data_feature_points = list(map(int, data_sin["feature_points"]))

        feature_maxt[i, -1] = data_sin["age"]  # 最后一列为 age
        feature_maxt[i, -2] = 1 if data_sin["Sex"] == 'Male' else 0  # 性别
        feature_maxt[i, -3] = data_sin["SBP"]  # 收缩压

        # 时间特征
        feature_maxt[i, 0] = data_feature_points[2] - data_feature_points[0]
        feature_maxt[i, 1] = data_feature_points[0]
        feature_maxt[i, 2] = data_feature_points[3]
        feature_maxt[i, 3] = len(data_sig) - data_feature_points[3]

        # 高度特征
        feature_maxt[i, 4] = data_sig[data_feature_points[1]]
        feature_maxt[i, 5] = data_sig[data_feature_points[2]]
        feature_maxt[i, 6] = data_sig[data_feature_points[3]]
        feature_maxt[i, 7] = data_sig[data_feature_points[4]] - data_sig[data_feature_points[3]]
        feature_maxt[i, 8] = data_sig[data_feature_points[2]] / data_sig[data_feature_points[0]]
        feature_maxt[i, 9] = data_sig[data_feature_points[3]] / data_sig[data_feature_points[0]]
        feature_maxt[i, 10] = feature_maxt[i, 7] / data_sig[data_feature_points[0]]

        # 面积特征
        feature_maxt[i, 11] = simps(data_sig, np.linspace(0, len(data_sig), len(data_sig)))
        feature_maxt[i, 12] = simps(data_sig[0:data_feature_points[3]], np.linspace(0, data_feature_points[3], data_feature_points[3]))
        feature_maxt[i, 13] = simps(data_sig[data_feature_points[3]:], np.linspace(data_feature_points[3], len(data_sig), len(data_sig) - data_feature_points[3]))

        # 波谷宽度
        result = -np.abs([x - 0.75 for x in data_sig])
        valleys, _ = find_peaks(result)
        if len(valleys) < 2:
            feature_maxt[i, 14] = 0  # 默认值
        else:
            valleys_values = result[valleys]
            indices = valleys_values.argsort()[-2:][::-1]
            indices_ = valleys[indices]
            feature_maxt[i, 14] = np.abs(indices_[0] - indices_[1])

    except (KeyError, IndexError) as e:
        print(f"跳过错误数据：{e}")
        continue

#------------------------------------------------------------------------------------------------------------------------KDM Model Start
X = feature_maxt[:, np.array(range(0, feature_maxt.shape[1] - 1, 1))]  # 自变量
Y = feature_maxt[:, -1]  # 因变量

model = LinearRegression()
model.fit(X, Y)
X_test = X
Y_test = Y
def KDM_Age(X, Y, X_test, Y_test):
    # 导入本函数，需要的库
    import statsmodels.api as sm
    import numpy as np
    from sklearn.linear_model import LinearRegression
    from sklearn.metrics import mean_squared_error
    import statistics
    """
    使用 KDM 模型求解并输出 KDM 年龄

    Parameters:
    X0: 训练数据输入特征矩阵 (例如，脉搏信号数据)
    hage0: 训练数据的年龄向量
    X0_test: 测试数据输入特征矩阵
    hage0_test: 测试数据的年龄向量

    Returns:
    y2_BA: KDM年龄
    """
    # 定义一个存放预测值
    KDM_age = np.zeros((1, len(Y_test)))
    table_kdm = np.zeros((3, X.shape[1]))
    for i in range(X.shape[1]):
        xx = X[:, i].reshape(1, -1).T
        Y1 = Y.reshape(1, -1).T
        model = LinearRegression()
        # 第一步拟合，第二步做并做残差分析
        model.fit(Y1, xx)
        residuals = model.predict(Y1) - xx
        indices = [index for index, value in enumerate(residuals) if
                   -2.3 * np.std(residuals) < value < 2.3 * np.std(residuals)]
        # 第三步拟合，获得参数
        xx_new = xx[indices]
        yy_new = Y1[indices]
        model.fit(yy_new, xx_new)
        xx_new_pre = model.predict(yy_new)

        table_kdm[0, i] = model.intercept_
        table_kdm[1, i] = model.coef_
        table_kdm[2, i] = np.sqrt(mean_squared_error(xx_new, xx_new_pre))

    # ***第二步：利用table计算预测值
    # 计算整体X作为输入时的，回归RMSE，记作Sba
    model1 = LinearRegression();
    model1.fit(X, Y)
    Y_pred = model1.predict(X)
    Sba = np.sqrt(mean_squared_error(Y, Y_pred))
    print(f'RMSE:{Sba}')

    # 计算预测值
    for i in range(len(Y_test)):
        xxx = X_test[i, :]
        fenzi = np.dot((xxx - table_kdm[0, :]), (table_kdm[1, :] / (table_kdm[2, :] ** 2))) + Y_test[i] / (Sba ** 2)
        fenmu = np.dot(table_kdm[1, :] / table_kdm[2, :], table_kdm[1, :] / table_kdm[2, :]) + 1 / (Sba ** 2)
        KDM_age[0, i] = fenzi / fenmu;
    return KDM_age


KDM = KDM_Age(X, Y, X_test, Y_test)
plt.rcParams.update({'font.size': 20})
plt.figure(figsize=(8, 6), dpi=150)
plt.scatter(Y, KDM, s=10, alpha=0.5, c='#000000')  # 透明度 0.5，蓝色点
# 添加标题和坐标轴标签
plt.title('Klemera-Doubal Method Model')
plt.xlabel('Chronological Age (Y)')
plt.ylabel('Vascular Age (KDM)')
# 添加参考线
plt.plot([10, 90], [10, 90], color='#B0B0B0')  # 对角线
# 设置坐标轴范围
plt.xlim(10, 90)
plt.ylim(10, 90)
# 显示图形
plt.show()
#--------------------------------------------------------------------------------------------------------------------------KDM Model end


#--------------------------------------------------------------------------------------------------------------------------RF Model Start
X = feature_maxt[:, :-1]  # 所有特征列（除 age 列）
y = feature_maxt[:, -1]   # 目标变量 age

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 构建随机森林模型
rf_model = RandomForestRegressor(n_estimators=100, random_state=42, max_depth=25)

# 训练模型
rf_model.fit(X_train, y_train)

# 在测试集上进行预测
y_pred = rf_model.predict(X_test)

# 计算 RMSE
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"模型性能评估：")
print(f"RMSE (均方根误差): {rmse:.4f}")


plt.rcParams.update({'font.size': 20})
plt.figure(figsize=(8, 6), dpi=150)
plt.scatter(y_test, y_pred, s=10, alpha=0.5, c='#000000')  # 透明度 0.5，蓝色点

# 添加标题和坐标轴标签
plt.title('Random Forest Model')
plt.xlabel('Chronological Age (Y)')
plt.ylabel('Vascular Age (RF)')

# 添加参考线
plt.plot([10, 90], [10, 90], color='#B0B0B0')  # 对角线

# 设置坐标轴范围
plt.xlim(10, 90)
plt.ylim(10, 90)
# 显示图形
plt.show()
#--------------------------------------------------------------------------------------------------------------------------RF Model end

#--------------------------------------------------------------------------------------------------------------------------MLR Model Start
# 特征和目标变量划分
X = feature_maxt[:, :-1]  # 所有特征列（除 age 列）
y = feature_maxt[:, -1]   # 目标变量 age

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 使用多元线性回归模型
linear_reg_model = LinearRegression()

# 训练模型
linear_reg_model.fit(X_train, y_train)

# 在测试集上进行预测
y_pred = linear_reg_model.predict(X_test)

# 计算 RMSE
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"模型性能评估：")
print(f"RMSE (均方根误差): {rmse:.4f}")

plt.rcParams.update({'font.size': 20})
# 可视化预测值与实际值
plt.figure(figsize=(8, 6), dpi=150)
plt.scatter(y_test, y_pred, s=10, alpha=0.5, c='#000000')  # 透明度 0.5，蓝色点

# 添加标题和坐标轴标签
plt.title('Multiple Linear Regression Model')
plt.xlabel('Chronological Age (Y)')
plt.ylabel('Vascular Age (Predicted)')

# 添加参考线
plt.plot([10, 90], [10, 90], color='#B0B0B0')  # 对角线

# 设置坐标轴范围
plt.xlim(10, 90)
plt.ylim(10, 90)

# 显示图形
plt.show()
#--------------------------------------------------------------------------------------------------------------------------RF Model end